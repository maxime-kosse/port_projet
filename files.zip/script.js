// ----- Données de la carte (à modifier librement) -----
const MENU = {
  "Entrées": [
    { n: "Velouté de potimarron", d: "Crème fraîche, graines torréfiées, huile de noisette.", p: 9, veg: true },
    { n: "Burrata et figues rôties", d: "Miel de thym, roquette, pain grillé.", p: 12, veg: true },
    { n: "Tartare de daurade", d: "Citron vert, aneth, huile d’olive.", p: 13 },
    { n: "Œuf parfait", d: "Purée de panais, champignons sautés.", p: 10, veg: true }
  ],
  "Plats": [
    { n: "Risotto aux cèpes", d: "Parmesan 24 mois, persil plat.", p: 19, veg: true },
    { n: "Filet de bar", d: "Fenouil braisé, beurre blanc au citron.", p: 24 },
    { n: "Souris d’agneau confite", d: "7 heures de cuisson, purée maison, jus réduit.", p: 25 },
    { n: "Gnocchi à la sauge", d: "Beurre noisette, courge rôtie, noix.", p: 18, veg: true }
  ],
  "Desserts": [
    { n: "Tarte fine aux poires", d: "Crème d’amande, glace vanille.", p: 8, veg: true },
    { n: "Mousse au chocolat noir", d: "Fleur de sel, éclats de noisettes.", p: 8, veg: true },
    { n: "Panna cotta", d: "Coulis de fruits rouges.", p: 7, veg: true },
    { n: "Assiette de fromages", d: "Trois fromages affinés, confiture de figues.", p: 10, veg: true }
  ]
};

const tabsEl = document.getElementById("tabs");
const dishesEl = document.getElementById("dishes");
const euro = n => n.toLocaleString("fr-FR") + " €";

function showCategory(cat) {
  tabsEl.querySelectorAll(".tab").forEach(b => b.setAttribute("aria-selected", String(b.dataset.cat === cat)));
  dishesEl.innerHTML = MENU[cat].map(x => `
    <li class="dish">
      <h3>${x.n}${x.veg ? '<span class="tag">Végé</span>' : ""}</h3>
      <span class="price">${euro(x.p)}</span>
      <p>${x.d}</p>
    </li>`).join("");
}

Object.keys(MENU).forEach((cat, i) => {
  const b = document.createElement("button");
  b.className = "tab";
  b.type = "button";
  b.role = "tab";
  b.textContent = cat;
  b.dataset.cat = cat;
  b.addEventListener("click", () => showCategory(cat));
  tabsEl.appendChild(b);
  if (i === 0) showCategory(cat);
});

// ----- Menu mobile -----
const burger = document.getElementById("burger");
const links = document.getElementById("links");
burger.addEventListener("click", () => {
  const open = links.classList.toggle("open");
  burger.setAttribute("aria-expanded", String(open));
});
links.addEventListener("click", e => {
  if (e.target.tagName === "A") { links.classList.remove("open"); burger.setAttribute("aria-expanded", "false"); }
});

// ----- Formulaire de réservation -----
const form = document.getElementById("form");
const dateInput = document.getElementById("date");
const today = new Date().toISOString().split("T")[0];
dateInput.min = today;

form.addEventListener("submit", e => {
  e.preventDefault();
  const f = new FormData(form);
  const errors = {};
  if (!f.get("name").trim()) errors.name = "Indiquez votre nom.";
  if (!/^[0-9 +().-]{8,}$/.test(f.get("phone").trim())) errors.phone = "Entrez un numéro valide (8 chiffres minimum).";
  if (!f.get("date")) errors.date = "Choisissez une date.";
  else if (f.get("date") < today) errors.date = "Cette date est passée.";
  else if (new Date(f.get("date") + "T12:00").getDay() === 1) errors.date = "Nous sommes fermés le lundi.";

  ["name", "phone", "date"].forEach(k => document.getElementById("e-" + k).textContent = errors[k] || "");
  const confirm = document.getElementById("confirm");
  if (Object.keys(errors).length) { confirm.hidden = true; return; }

  const d = new Date(f.get("date") + "T12:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
  confirm.textContent = `Merci ${f.get("name").trim()} ! Demande reçue pour ${f.get("guests")} personne(s), ${d} à ${f.get("time")}. Nous vous rappelons pour confirmer.`;
  confirm.hidden = false;
  form.reset();
  document.getElementById("guests").value = "2";
  document.getElementById("time").value = "19:30";
});
